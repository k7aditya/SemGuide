const appConfigSem4 = [
  {
    subjectName: 'Software Engineering',
    subjectShort: 'SE',
    subjectCode: '19',
    path: '/',
    image: '',
  },
  {
    subjectName: 'Design and Analysis of Algorithms',
    subjectShort: 'DAA',
    subjectCode: '20',
    path: '/',
    image: '',
  },
  {
    subjectName: 'Computer Networks',
    subjectShort: 'CN',
    subjectCode: '21',
    path: '/',
    image: '',
  },
  {
    subjectName: 'Database Management System',
    subjectShort: 'DBMS',
    subjectCode: '22',
    path: '/',
    image: '',
  },
  {
    subjectName: 'Proncipes of Programming Languages',
    subjectShort: 'PPL',
    subjectCode: '23',
    path: '/',
    image: '',
  },
  {
    subjectName: 'Entrepreneuship',
    subjectShort: 'Minor-1',
    subjectCode: '24',
    path: '/',
    image: '',
  },
];

export default appConfigSem4;
