export { default as FeedbackView } from './feedback-view';
