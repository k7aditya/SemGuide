export { default as InfoView } from './info-view';
