export { default as PapersView } from './papers-view';
